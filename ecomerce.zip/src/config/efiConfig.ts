export = {
    // PRODUÇÃO = false
    // HOMOLOGAÇÃO = true
    sandbox: false,
    client_id: 'seuClientId',
    client_secret: 'seuClientSecret',
    pix_cert: 'caminhoAteOCertificadoPix',
};